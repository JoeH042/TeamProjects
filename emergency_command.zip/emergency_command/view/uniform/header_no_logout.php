<?php
 ?>

<!--Use this header file when the user is not logged in. Note, the only navigation option as a logged out user is "login". -->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Incident Command</title>
        <!--<link rel="stylesheet" type="text/css" href= "http://webdesign.cs.wright.edu/~rhodes/css/normalize.css"> -->
        <!--<link rel="stylesheet" type="text/css" href= "http://webdesign.cs.wright.edu/~rhodes/css/main.css"> -->
        <link rel="stylesheet" type="text/css" href= "css/normalize.css">
        <link rel="stylesheet" type="text/css" href= "css/main.css">
    </head>
    <body>
        <header>
            <!--logo here -->
            <h1>Incident Command Database</h1>
        </header>
        
        