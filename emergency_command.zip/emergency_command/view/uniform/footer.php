<?php

 ?>


        
        <footer>
            <p class="copyright"> 
                &copy; <?php echo date("Y"); ?> Incident Command (Davenport, Henning, Rhodes, Wang) </p>
        </footer>
    </body>
</html>
