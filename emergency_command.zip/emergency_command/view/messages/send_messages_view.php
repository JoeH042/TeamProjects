<?php
    //require_once('/util/secure_conn.php');  // require a secure connection
    require_once('/util/valid_admin.php');  // require a valid user

    include 'view/uniform/header.php';
?> 

<main>
    <h1>Send Messages To be implemented </h1>
</main>

<?php include 'view/uniform/footer.php'; ?>