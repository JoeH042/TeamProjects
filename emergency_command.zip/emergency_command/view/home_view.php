<?php
    //require_once('util/secure_conn.php');  // require a secure connection
    require_once('util/valid_user.php');  // require a valid user
?>


<?php include 'view/uniform/header.php'; ?>
   
<h1>Personal Statistics</h1>

<h1>Fancy Queries</h1>

<?php include 'view/uniform/footer.php'; ?>
